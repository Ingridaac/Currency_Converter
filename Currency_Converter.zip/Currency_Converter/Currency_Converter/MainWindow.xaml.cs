﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;

namespace Currency_Converter
{
    
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        public static class CurrencyConverterWords
        {
            public static CurrencyMember ConvertingNumbersToWords(string currencyNumber)
            {
                CurrencyMember response = new CurrencyMember();
                string isNegativeNr = "";
                try
                {

                    string number = currencyNumber.Replace(',', '.').Trim().Replace(" ", "");

                    if (number.Contains(','))
                    {
                        number = Double.Parse(number).ToString(".00");
                    }
                    else
                    {
                        number = Double.Parse(number).ToString();
                    }

                    if (number.Contains("-"))
                    {
                        isNegativeNr = "Minus ";
                        number = number.Substring(1, number.Length - 1);
                    }
                    if (number == "0")
                    {
                        response.Result = "zero dollar";
                    }

                    else
                    {
                        response.Result = (isNegativeNr + CurrencyConverterWords.ConvertingToWords(number)).ToLower();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return response;
            }

            //Converting the whole number
            private static string ConvertWholeNr(string wholeNumber)
            {
                string wordForNr = "";
                try
                {
                    bool beginsWithZero = false;
                    bool isDone = false;
                    double dblAmount = (Double.Parse(wholeNumber));

                    if (dblAmount > 0 || dblAmount == 0 )
                    {
                        beginsWithZero = wholeNumber.StartsWith("0");

                        int digits = wholeNumber.Length;
                        int position = 0;
                        string place = "";
                        switch (digits)
                        {
                            //ones' range    
                            case 1: 
                                wordForNr = ones(wholeNumber);
                                isDone = true;
                                break;
                            //tens' range
                            case 2:     
                                wordForNr = tens(wholeNumber);
                                isDone = true;
                                break;
                            //hundreds' range  
                            case 3:   
                                position = (digits % 3) + 1;
                                place = " hundred ";
                                break;
                            //thousands' range   
                            case 4: 
                            case 5:
                            case 6:
                                position = (digits % 4) + 1;
                                place = " thousand ";
                                break;
                            case 7: //millions' range    
                            case 8:
                            case 9:
                                position = (digits % 7) + 1;
                                place = " million ";
                                break;
                            case 10: //Billions's range    
                            case 11:
                            case 12:
                                position = (digits % 10) + 1;
                                place = " billion ";
                                break;
                            default:
                                isDone = true;
                                break;
                        }
                        if (!isDone)
                        {
                            if (wholeNumber.Substring(0, position) != "0" && wholeNumber.Substring(position) != "0")
                            {
                                try
                                {
                                    wordForNr = ConvertWholeNr(wholeNumber.Substring(0, position)) + place + ConvertWholeNr(wholeNumber.Substring(position));
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex);
                                }
                            }
                            else
                            {
                                wordForNr = ConvertWholeNr(wholeNumber.Substring(0, position)) + ConvertWholeNr(wholeNumber.Substring(position));
                            }
                        }
                        
                        if (wordForNr.Trim().Equals(place.Trim())) wordForNr = "";
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                return wordForNr.Trim();
            }

            //tens
            private static string tens(string tensNumber)
            {
                int TNumber = Int32.Parse(tensNumber);
                string TName = null;
                switch (TNumber)
                {
                    case 0:
                        TName = "";
                        break;
                    case 10:
                        TName = "ten";
                        break;
                    case 11:
                        TName = "eleven";
                        break;
                    case 12:
                        TName = "twelve";
                        break;
                    case 13:
                        TName = "thirteen";
                        break;
                    case 14:
                        TName = "fourteen";
                        break;
                    case 15:
                        TName = "fifteen";
                        break;
                    case 16:
                        TName = "sixteen";
                        break;
                    case 17:
                        TName = "seventeen";
                        break;
                    case 18:
                        TName = "eighteen";
                        break;
                    case 19:
                        TName = "nineteen";
                        break;
                    case 20:
                        TName = "twenty";
                        break;
                    case 30:
                        TName = "thirty";
                        break;
                    case 40:
                        TName = "fourty";
                        break;
                    case 50:
                        TName = "fifty";
                        break;
                    case 60:
                        TName = "sixty";
                        break;
                    case 70:
                        TName = "seventy";
                        break;
                    case 80:
                        TName = "eighty";
                        break;
                    case 90:
                        TName = "ninety";
                        break;
                    default:
                        if (TNumber > 0)
                        {
                            var val = tens(tensNumber.Substring(0, 1) + "0");
                            if (string.IsNullOrEmpty(val))
                            {
                                TName = ones(tensNumber.Substring(1));
                            }
                            else
                            {
                                TName = val + "-" + ones(tensNumber.Substring(1));
                            }

                        }
                        break;
                }
                return TName;
            }

            //ones
            private static string ones(string onesNumber)
            {
                int ONumber = Int32.Parse(onesNumber);
                string OName = "";
                switch (ONumber)
                {
                    case 0:
                        OName = "zero";
                        break;
                    case 1:
                        OName = "one";
                        break;
                    case 2:
                        OName = "two";
                        break;
                    case 3:
                        OName = "three";
                        break;
                    case 4:
                        OName = "four";
                        break;
                    case 5:
                        OName = "five";
                        break;
                    case 6:
                        OName = "six";
                        break;
                    case 7:
                        OName = "seven";
                        break;
                    case 8:
                        OName = "eight";
                        break;
                    case 9:
                        OName = "nine";
                        break;
                }
                return OName;
            }

            // Converting Decimal
            public static  string ConvertingToWords(string number)
            {
                string value = "", wholeNr = number, points = "", andString = "", pointString = "";
                string endString = "dollars";
                string validationError = "Invalid Input!";

                //Display possible erros that may occur
                try
                {

                    if (number.Replace(" ", "").Length > 12)
                    {
                        string errorValue = "Maximum allowed Value - 999999999,99";
                        return errorValue;
                    }
                    if (!Regex.Match(number, @"(^([0-9\s\,]*)$)").Success)
                    {
                        return validationError + " Only coma (,) is allowed";
                    }
                    if (number.Count(x => x == ',') > 1)
                    {
                        return validationError;
                    }
                    // can not allow comma as last character 
                    if (number.Length > 0 && number.Substring(number.Length - 1, 1) == ",")
                    {
                        return validationError;
                    }
                    // maximum number of characters after comma is 2
                    if (number.Length > 0 && number.Contains(',') && (!Regex.Match(number, @"(,[0-9]{0,2}$)").Success))
                    {
                        return validationError;
                    }
                    //enter a currency in order for Convert Button to function
                    if (string.IsNullOrEmpty(number))
                    {
                        string nullValue = "Please enter a value";
                        return nullValue;
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

                if (number == "1")
                {
                    endString = "dollar";
                }
                try
                {
                    int decimalNr = number.IndexOf(",");
                    if (decimalNr > 0)
                    {
                        wholeNr = number.Substring(0, decimalNr);
                        points = number.Substring(decimalNr + 1);
                        if (Int32.Parse(points) > 0 && Int32.Parse(points) <= 1)
                        {
                            //dividing the whole number from comma
                            andString = endString + " and "; 
                            endString = "cent";    
                            pointString = ConvertingDecimals(points);
                        }
                        else
                        {
                            if (Int32.Parse(points) > 1)
                            {
                                //dividing the whole number from comma
                                andString = endString + " and ";  
                                endString = "cents"; //Cents if number of cents > 1 
                                pointString = ConvertingDecimals(points);
                            }
                        }
                    }
                    // Filling the string which containt the requested format of word convert
                    value = String.Format("{0} {1}{2}{3}", ConvertWholeNr(wholeNr).Trim(), andString, pointString, endString);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                return value;
            }

            private static String ConvertingDecimals(string number)
            {
                var finalOutput =  ConvertingNumbersToWords(number);
                return finalOutput.Result.Replace("dollar", "");

            }
      
        }


        private void Convert_Button(object sender, RoutedEventArgs e)
        {
            string number = txtCurrency.Text;
            test.Text = CurrencyConverterWords.ConvertingToWords(number);
        }
      
    }
}


